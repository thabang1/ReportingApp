
<?php
    if(isset($_POST['submit']))
    {
        $test1=$_POST['test1'];
        $test2 = $_POST['test2'];
        mysql_connect("localhost", "root", "") or die(mysql_error()); 
        mysql_select_db("report") or die(mysql_error()); 
        mysql_query("INSERT INTO reports (test1,test2) VALUES ('$test1', '$test2')"); 
        Print "Your information has been successfully added to the database."; 
    }
?> 