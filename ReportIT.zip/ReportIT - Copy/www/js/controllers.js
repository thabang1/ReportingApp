angular.module('starter.controllers', [])


.controller('PopupCtrl',function($scope, $ionicPopup, $timeout,$http) {

// Triggered on a button clicked
$scope.showPopup = function() {
  $scope.data = {};

  // An elaborate, custom popup
  var idPrompt = $ionicPopup.show({
    template: '<input type="text" ng-model="data.login">',
    title: 'Welcome to ABC Municipality ',
    subTitle: 'Please enter your ID Number',
    scope: $scope,
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Send</b>',
        type: 'button-positive',
      }
    ]
  });

// Triggered when send button is clicked and ID number is entered         
  idPrompt.then(function() {
     var myIncident = $ionicPopup.show({                    
            template: '1.Water<br>2.Electricity<br> 3.Roads <br>4.Sewege <br>5.Crime <br>4.Other<input type="text" ng-model="data.incident">',
            title: 'Please select Incident Type',
            subTitle: '', 
            scope: $scope,  
            buttons: [
                        { text: 'Cancel' },
                        {
                            text: '<b>Send</b>',
                        type: 'button-positive',
                        onTap: function(e) {
                            if (!$scope.data.incident) {
          
            e.preventDefault();
          } else {
            return $scope.data.incident;
          }
        }
      }
    ]
  });    

      //##############################################################################################################################   
    
      // Triggered when Water is entered
      myIncident.then(function(res){      
          if (res== "1"){    
                        var myWaterPopUp = $ionicPopup.show({                    
                        template: '1.Burst water Pipe<br>2.Blocked Drain <br>3.Water Hydrant Leaks<br> 4.Water Hydrant Burst 5.Damaged Water Meter 6.No Water Supply.<input type="text" ng-model="data.water">',
                        title: 'Please select Water Incident Type',
                        subTitle: '', 
                        scope: $scope,  
                        buttons: [
                        { text: 'Cancel' },
                        {
                        text: '<b>Send</b>',
                        type: 'button-positive',
                        onTap: function(e) {
                            if (!$scope.data.water) {
            //don't allow the user to close unless he enters wifi password
            e.preventDefault();
          } else {
            return $scope.data.water;
          }
        }
      }
    ]
  }); 
        
  myWaterPopUp.then(function()
                   { 
  

  
    var mystreetPopUp = $ionicPopup.show({                    
    template: 'Please enter the suburb/township and street names <input type="text" ng-model="data.street">',
    title: 'Please enter the street address', 
    scope: $scope,  
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Send</b>',
        type: 'button-positive',
        onTap: function(e) {
          if (!$scope.data.street) {
            //don't allow the user to close unless he enters wifi password
            e.preventDefault();
          } else {
            return $scope.data.street;
          }
        }
      }
    ]
  }); 
  
  mystreetPopUp.then(function(){
      
      
             var confirm = $ionicPopup.show({                    
          template: '',
    title: 'Thank for your submission, our agents are attending to it , Reference No: 002214',
    subTitle: '', 
    scope: $scope,  
    buttons: [
      { text: 'ok' },
  
    ]
  }); 
          
  });
  
  
  });  
 
              
function prepareOutput(payload){
    
    http
    
    
    
    
    
}               


              
    }
          
 //##############################################################################################################################   
              
          
          
          
          else if(res =="2"){
   // Triggered when Electricity option button is clicked       
 
    var myElecricityPopUp = $ionicPopup.show({                    
    template: '1.Damaged Main Switch <br>2.Faulty Street Lights<br> 3.Powercut <br>4.Other<input type="text" ng-model="data.electricity">',
    title: 'Please select Electricity Incident Type',
    subTitle: '', 
    scope: $scope,  
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Send</b>',
        type: 'button-positive',
        onTap: function(e) {
          if (!$scope.data.electricity) {
            //don't allow the user to close unless he enters wifi password
            e.preventDefault();
          } else {
            return $scope.data.electricity;
          }
        }
      }
    ]
  });    
       
                   
       myElecricityPopUp.then(function()
                   {    
                    
           var mystreetPopUp = $ionicPopup.show({                    
    template: 'Please enter the suburb/township and street names <input type="text" ng-model="data.street">',
    title: 'Please enter the street address', 
    scope: $scope,  
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Send</b>',
        type: 'button-positive',
        onTap: function(e) {
          if (!$scope.data.street) {
            //don't allow the user to close unless he enters wifi password
            e.preventDefault();
          } else {
            return $scope.data.street;
          }
        }
      }
    ]
  }); 
      }                  
          );             
          }

          
 //##############################################################################################################################   
              
          
          
     else if(res =="3"){
              
     var myRoadPopUp = $ionicPopup.show({                    
         template: '1.Pot holes <br>2.Car Accident<br> 3.other <br>4.Other<input type="text" ng-model="data.road">',
    title: 'Please select Road Incident Type',
    subTitle: '', 
    scope: $scope,  
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Send</b>',
        type: 'button-positive',
        onTap: function(e) {
          if (!$scope.data.road) {
            //don't allow the user to close unless he enters wifi password
            e.preventDefault();
          } else {
            return $scope.data.road;
          }
        }
      }
    ]
  }); 
              
       myRoadPopUp.then(function()
                   {    
         
    var mystreetPopUp = $ionicPopup.show({                    
    template: 'Please enter the suburb/township and street names <input type="text" ng-model="data.street">',
    title: 'Please enter the street address', 
    scope: $scope,  
    buttons: [
      { text: 'Cancel' },
      {
        text: '<b>Send</b>',
        type: 'button-positive',
        onTap: function(e) {
          if (!$scope.data.street) {
            //don't allow the user to close unless he enters wifi password
            e.preventDefault();
          } else {
            return $scope.data.street;
          }
        }
      }
    ]
  }); 
          
});  
                     
          }
 
          

          
          
      })
  
      
  });
 
 };

});
